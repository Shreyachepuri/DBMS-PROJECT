import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import javax.swing.*;


public class Profile
{
    
    JLabel heading = new JLabel("Profile");

    JLabel l1 = new JLabel("Admin ID : ");
    JLabel l2 = new JLabel("User Name :");
    JLabel l3= new JLabel("Password : ");
    JLabel l4 = new JLabel("Name: ");
    JLabel l5 = new JLabel("Email : ");
    JLabel l6 = new JLabel("contact : ");
    JLabel go_to = new JLabel("GOTO");

    JTextField tf1 = new JTextField();
    JTextField tf2 = new JTextField();
    JPasswordField tf3 = new JPasswordField();
	JTextField tf4 = new JTextField();
    JTextField tf5 = new JTextField();
    JTextField tf6 = new JTextField();
	JTextField tf7 = new JTextField();
    //JTextArea resultText = new JTextArea();
    
    JButton home = new JButton("Home");
    //JButton insert = new JButton("Submit");
    JButton back = new JButton("Back");

    PreparedStatement stmt;
   

    public Profile(){
    	
    	


        heading.setBounds(50, 50, 100, 20);
        l1.setBounds(50, 100, 130, 30);
        l2.setBounds(50, 150, 200, 30);
        tf1.setBounds(250, 100, 150, 30); 
       	tf2.setBounds(250, 150, 150, 30);
        l3.setBounds(50, 200, 150, 30);
        tf3.setBounds(250, 200, 150, 30);
		tf3.setEchoChar('*');
        l4.setBounds(50, 250, 150, 30);
        tf4.setBounds(250, 250,150, 30);
        l5.setBounds(50, 300, 150, 30);
        tf5.setBounds(250, 300, 150, 30);
        l6.setBounds(50, 350, 150, 30);
        tf6.setBounds(250, 350, 150, 30);
        
        //resultText.setBounds(250, 450, 200, 150);
        
        //insert.setBounds(50, 450, 100, 30);
        go_to.setBounds(50, 500, 100, 30);
        home.setBounds(50, 550, 100, 30);
        back.setBounds(50, 600, 100, 30);

        frame.add(heading);
        frame.add(l1);
        frame.add(l2);
        frame.add(tf1);
        frame.add(tf2);
        frame.add(l3);
        frame.add(tf3);
        frame.add(l4);
        frame.add(tf4);
        frame.add(l5);
        frame.add(tf5);
        frame.add(l6);
        frame.add(tf6);
        
        frame.add(insert);
        frame.add(go_to);
        frame.add(home); 
        //frame.add(resultText);
        frame.add(back);
        
        frame.setLayout(null);  
        frame.setVisible(true);
        frame.setBounds(10, 10, 500, 700);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setResizable(false);  

        insert.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent ae) {
            
            try {	
			  
                    
				    Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","shreya","vasavi123");
				    PreparedStatement stmt=con.prepareStatement("select  from admin where id=101");
                    /*stmt.setInt(1,Integer.parseInt(tfId.getText()));	
                    stmt.setString(2,tfuserName.getText());	
                    stmt.setString(3,tfps.getText());	
                    stmt.setString(4,tfcompName.getText());	
                    stmt.setString(5,tfem.getText());	
                    stmt.setString(6,tfweb.getText());	
                    stmt.setInt(7,Integer.parseInt(tfcont.getText()));	
                    rs=stmt.executeUpdate();*/
					/*if(rs.next())
					{
						int id = rs.getInt("Admin_id");
						tf1.setText(id);
						String username = rs.getString("User Name");
						tf2.setText(username);
						String ps = rs.getString("*/
                    System.out.println(i + "records inserted");	
					resultText.append("Inserted" + i + "rows successfully"); 
					con.close();
                    
	                 
	             
            }
            catch(SQLException e){
                System.out.println(e);
            }
            

            
        }});

        home.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent ae) {
            frame.dispose();
            new MainPage();
            
         
        }});
        
        back.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
               frame.dispose();
               new Admin1();
              
            
           }});
   
    }   
}



