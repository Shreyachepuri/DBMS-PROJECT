import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Update_Jobseeker
{
    JFrame frame = new JFrame("PROFILE");

    JLabel heading = new JLabel("USER PROFILE");

    JLabel Name = new JLabel("NAME :");
    JLabel email = new JLabel("EMAIL: ");
    JLabel con = new JLabel("CONTACT : ");
    JLabel gen = new JLabel("GENDER: ");
    JLabel skills = new JLabel("SKILLS : ");
    JLabel qual = new JLabel("QUALIFICATION: ");
	JLabel work = new JLabel("ANY WORK EXPERIENCE(YES/NO): ");
    JLabel go_to = new JLabel("GOTO"); 
    JTextField tName = new JTextField();
    JTextField temail = new JTextField();
    JTextField tcon = new JTextField();
    JTextField tgen = new JTextField();
    JTextField tskills = new JTextField();
    JTextField tqual = new JTextField();
	JTextField twork = new JTextField();
    
    JButton home = new JButton("Home");
    JButton modify = new JButton("MODIFY");
    JButton back = new JButton("Back");

    Statement stmt;
    
    public void connDb() {
    	try{
            
        
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","shreya","vasavi123");
            
            System.out.println("connection successful");

        }
        catch(SQLException e){
            System.out.println(e);
        }
    }

  

    public Update_Jobseeker(){
    	
    	connDb();
 
        heading.setBounds(5,2,90,50);
	    Name.setBounds(20,20,40,70);
        tName.setBounds(180,43,165,23);
		
        email.setBounds(20,70,80,70);
        temail.setBounds(180,93,165,23);
		
        con.setBounds(20,120,100,70);
        tcon.setBounds(180,143,165,23);
		
        gen.setBounds(20, 170,100,70);
        tgen.setBounds(180, 193, 165, 23);
		
        skills.setBounds(20, 220, 140, 70);
        tskills.setBounds(180,243, 165, 30);
		
        qual.setBounds(20, 270, 100, 70);
        tqual.setBounds(180, 293, 165, 30);
		
		work.setBounds(20, 320, 150, 70);
        twork.setBounds(180, 343, 165, 30);
		
        modify.setBounds(50, 470, 100, 30);
        go_to.setBounds(50, 520, 100, 30);
        home.setBounds(200, 520, 100, 30);
        back.setBounds(450, 520, 100, 30);
        
        
        
        frame.add(heading);
        
        frame.add(Name);
        
        frame.add(tName);
		
        frame.add(email);
        frame.add(temail);
		
        frame.add(con);
        frame.add(tcon);
		
        frame.add(gen);
        frame.add(tgen);
		
        frame.add(skills);
        frame.add(tskills);
		
        frame.add(qual);
        frame.add(tqual);
		
		frame.add(work);
        frame.add(twork);
		
		
		
        frame.add(modify);
        frame.add(go_to);
        frame.add(home); 
        
        frame.add(back);
        
        frame.setLayout(null);  
        frame.setVisible(true);
        frame.setBounds(40,40,600,800);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setResizable(false);  
		
		
			

        try
		{		
		            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","shreya","vasavi123");
                    System.out.println("connection successful");
            	    ResultSet rs;
					PreparedStatement stmt = con.prepareStatement("SELECT * FROM jobseeker1");
					rs = stmt.executeQuery();
                    rs.next();
                    tName.setText(String.valueOf(rs.getString(1)));
                    temail.setText(rs.getString(2));
                    tcon.setText(rs.getString(3));
                    tgen.setText(rs.getString(4));
                    tskills.setText(String.valueOf(rs.getString(5)));
                    tqual.setText(rs.getString(6));
                    twork.setText(rs.getString(7));
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}

        modify.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent ae){ 
       
            
            try     
            {
				    
					
					JOptionPane.showMessageDialog(new JFrame(),"Successfully Updated!","NOTICE",JOptionPane.INFORMATION_MESSAGE);
                    int i = stmt.executeUpdate("UPDATE jobseeker1 SET username= ' " + tName.getText() + " ',email='" + temail.getText() + "',contact= '" + tcon.getText() + "', gender='" + tgen.getText() + "',skills='" + tskills.getText() + "', qual='" + tqual.getText() + "',work ='"+ twork.getText()+"'");
				
				
						JOptionPane.showMessageDialog(new JFrame(),"Successfully Updated!","NOTICE",JOptionPane.INFORMATION_MESSAGE); 
                    
					
					
            	    
                } 
                catch (SQLException e) 
                {
                    System.out.println(e);
                }
        }});

       
        home.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent ae) {
            frame.dispose();
            new HomePage1();
            
         
        }});
        
        back.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
               frame.dispose();
               new MainPage();
               
           }});
   
    }   
}