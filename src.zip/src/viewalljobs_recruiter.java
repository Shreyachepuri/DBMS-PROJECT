import java.awt.*;

import javax.swing.*;

public class viewalljobs_recruiter {
	
	viewalljobs_recruiter(){
	
		JFrame frame = new Job_List_Recruiter();
		
        frame.setTitle("JOB LIST");
        frame.setSize(5000, 3000);
        frame.setLocationRelativeTo(null);
		frame.pack();
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
	    
	}
}