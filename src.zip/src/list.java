import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.table.*;
import java.sql.*;
public class list extends JFrame {
	 JFrame frame = new JFrame();
	 DefaultTableModel model = new DefaultTableModel();
	 //Container cnt = new Container();
	 JTable jtbl = new JTable(model);
	 
	 
	 
	 
	    public list() {
	        frame.setLayout(new FlowLayout(FlowLayout.LEFT));
	        model.addColumn("Recruiter ID");
	        model.addColumn("Username");
	        model.addColumn("Company name");
	        model.addColumn("Email");
	        model.addColumn("website");
	        model.addColumn("contact");
			jtbl.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
			jtbl.getColumnModel().getColumn(0).setPreferredWidth(70);
			jtbl.getColumnModel().getColumn(1).setPreferredWidth(100);
			jtbl.getColumnModel().getColumn(2).setPreferredWidth(150);
			jtbl.getColumnModel().getColumn(3).setPreferredWidth(150);
			jtbl.getColumnModel().getColumn(4).setPreferredWidth(80);
			jtbl.getColumnModel().getColumn(5).setPreferredWidth(90);
			//jtbl.setCellSelectionEnabled(true);
			jtbl.setRowSelectionAllowed(true);
	        String dburl ="jdbc:oracle:thin:@localhost:1521:xe";
			String us = "shreya";
			String pas ="vasavi123";
	        try {
	        	Connection  conn=DriverManager.getConnection(dburl,us,pas);
				System.out.println("Connected");
	           // Class.forName("com.mysql.jdbc.Driver");
	            //Connection con = DriverManager.getConnection("jdbc:mysql://localhost/java_db", "root", "");
	            PreparedStatement pstm = conn.prepareStatement("SELECT * FROM Addrecruiter");
	            ResultSet Rs = pstm.executeQuery();
	            while(Rs.next()){
	                model.addRow(new Object[]{Rs.getLong(1), Rs.getString(2),Rs.getString(4),Rs.getString(5),Rs.getString(6),Rs.getLong(7)});
	            }
	        } catch (Exception e) {
	            System.out.println(e.getMessage());
	        }
			
	        JScrollPane pg = new JScrollPane(jtbl);
			JButton upd = new JButton("Update");
			JButton dlt = new JButton("Delete");
	        pg.setBounds(10,10,400,400);
	        pg.createHorizontalScrollBar();
	        pg.createVerticalScrollBar();
	        frame.add(pg);
	        //this.pack();
	        //this.add(cnt);
			upd.setBounds(50,450,150,50);
			dlt.setBounds(300,450,150,50);
			frame.add(dlt);
			frame.add(upd);
			frame.setLayout(null);  
            frame.setVisible(true);
            frame.setBounds(10, 10, 600, 600);
            frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
            frame.setResizable(true);
			upd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				
				/*int i = jtbl.getSelectedRow();
                if(i >= 0){
                    // remove a row from jtable
                    model.removeRow(i);
                }
                else{
                    System.out.println("Delete Error");
					}*/
			    new update();
			   }
		   });
			dlt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				
				int i = jtbl.getSelectedRow();
                if(i >= 0){
                    // remove a row from jtable
                    model.removeRow(i);
                }
                else{
                    System.out.println("Delete Error");
					}
			    new Delete();
			   }
		   });
		   
		}
}