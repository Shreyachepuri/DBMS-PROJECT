import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class HomePage1 extends JFrame{
	private JFrame frame= new JFrame(); 
	//private JButton b1=new JButton("Admin");
	private JButton b2=new JButton("Job seeker");
	private JButton b3=new JButton("Recruiter");
	private JMenuBar mBar;
    private JMenu mnuHelp;
    private JMenuItem abt;
	public HomePage1(){       
        frame.setTitle("Home Page");
        frame.setLayout(null); 
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
        frame.setBounds(100,150,1000,400); 
		Container c=frame.getContentPane(); 
		//frame.getContentPane().add(b1);
		frame.getContentPane().add(b2);
		frame.getContentPane().add(b3);
		initializeMenuBar();
        frame.setJMenuBar(mBar);
		abt.addActionListener(new HelpMenuActionListener());
		JLabel label=new JLabel("CONSULTANCY SERVICES FOR JOB HUNT");
        label.setBounds(200,5,700,50);
		
        JLabel lable=new JLabel("REGISTER AS:");
        lable.setBounds(200,100,700,50);	
		
        label.setFont(new Font("Serif",Font.PLAIN,30));		
		//b1.setBounds(200,150,170,40);
		//b1.setFont(new Font("Times New Roman",Font.BOLD,17));
		b2.setBounds(300,150,170,40);
		b2.setFont(new Font("Times New Roman",Font.BOLD,17));
		b3.setBounds(500,150,170,40);
		b3.setFont(new Font("Times New Roman",Font.BOLD,17));
        /*b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				new AdminLogin();//Admin1();
			}
		});*/
        b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				frame.dispose();
				new RegistrationForm();
			}
		});
		b3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				new RegistrationForm_Rec();
			}
		});
             c.add(label);
			 c.add(lable);
			 
			frame.setVisible(true); 
	    }
		public void initializeMenuBar()
	    {
			mBar=new JMenuBar();
			mnuHelp=new JMenu("Help");
			abt=new JMenuItem("About");
			mnuHelp.add(abt);
			mBar.add(mnuHelp);
	    }	
		private class HelpMenuActionListener implements ActionListener {
			public void actionPerformed(ActionEvent ae) {
			if(ae.getSource()==abt)
			{
				String details;
				details = "This project is to enable interactions between employers and applicants"+"\n"+
                          "It has 2 main tables:"+"\n"+
                          "1.Admin and Jobseeker"+"\n"+
                          "2.Admin further accessed to adding a recruiter and viewing the Recruiter List and Userlist"+"\n"+
                          "3.JobSeeker accessed with profile and jObslist";
				JOptionPane.showMessageDialog(null,details,"INFORMATION", JOptionPane.INFORMATION_MESSAGE);
			}
		  }
		}
	
	
	public static void main(String args[]){
		new HomePage1();
    }
}
