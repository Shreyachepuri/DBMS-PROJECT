import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Admin1 extends JFrame{
	private JFrame frame= new JFrame(); 
	private JButton b1=new JButton("Add Recruiter");
	private JButton b2=new JButton("Recruiter List");
	private JButton b3=new JButton("User List");
	private JButton b4=new JButton("Profile");
	public Admin1(){       
        frame.setTitle("Admin Page");
        frame.setLayout(null); 
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);  
        frame.setBounds(100,150,1000,400); 
		Container c=frame.getContentPane(); 
		frame.getContentPane().add(b1);
		frame.getContentPane().add(b2);
		frame.getContentPane().add(b3);
		//frame.getContentPane().add(b4);
		b1.setBounds(400,60,170,40);
		b1.setFont(new Font("Times New Roman",Font.BOLD,17));
		b2.setBounds(400,110,170,40);
		b2.setFont(new Font("Times New Roman",Font.BOLD,17));
	    b3.setBounds(400,160,170,40);
		b3.setFont(new Font("Times New Roman",Font.BOLD,17));
		b4.setBounds(400,210,170,40);
		b4.setFont(new Font("Times New Roman",Font.BOLD,17));	
        b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				new AddRecruiter1();
			}
		});
       b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				new viewall();
			}
		});
        b3.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent ae) {
				new viewall_Users();
			}
		 });
        /* b4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				 new Profile();
			}
		});	*/	
			
			frame.setVisible(true); 
	    }
		
	
	
	public static void main(String args[]){
		new Admin1();
    }
}
