import java.awt.*;

import javax.swing.*;

public class viewall {
	
	viewall(){
	
		JFrame frame = new list();
		
        frame.setTitle("Recruiters List");
        frame.setSize(5000, 3000);
        frame.setLocationRelativeTo(null);
		frame.pack();
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
	    
	}
}