import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class Delete
{
    JFrame frame = new JFrame("Delete Recruiter");

    JLabel heading = new JLabel("DELETE Recruiter");

    JLabel Id = new JLabel("Enter id of student : ");
    JLabel pName = new JLabel("Enter User name :");
    JLabel des = new JLabel("password : ");
    JLabel dat = new JLabel("company name : ");
    JLabel course = new JLabel("email : ");
    JLabel code = new JLabel("website : ");
    JLabel score = new JLabel("contact: ");
    JLabel go_to = new JLabel("GOTO");


    List ids = new List(15);

    JTextField tpId = new JTextField();
    JTextField tpName = new JTextField();
    JTextField tscore = new JTextField();
    JTextField date = new JTextField();
    JTextField tcourse = new JTextField();
    JTextField tcode = new JTextField();
    JTextField tDescription = new JTextField();
    
    JTextArea resultText = new JTextArea();
    
    JButton home = new JButton("Home");
    JButton delete = new JButton("DELETE");
    JButton back = new JButton("Back");

    PreparedStatement stmt;
    
    /*public void connDb() {
    	try{
            //Class.forName("oracle.jdbc.driver.OracleDriver");
        
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@218.248.0.7:1521:rdbms","shreya","vasavi123");
            PreparedStatement stmt;
            System.out.println("connection successful");
//            con.close();
        }
        catch(SQLException e){
            System.out.println(e);
        }
    }*/

    public void loadProducts(){

        try 
        {
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","shreya","vasavi123");
            
            System.out.println("connection successful");
          ResultSet rs;
		  PreparedStatement stmt = con.prepareStatement("SELECT Recruiter_ID FROM addrecruiter");
          rs = stmt.executeQuery();
          while (rs.next()) 
          {
            ids.add(rs.getString(1));
          }
        } 
        catch (SQLException e) 
        { 
          displaySQLErrors(e);
        }
    }
    private void displaySQLErrors(SQLException e) 
    {
        JOptionPane.showMessageDialog(frame,"Enter valid data types");  
        resultText.append("\nSQLException: " + e.getMessage() + "\n");
        resultText.append("SQLState:     " + e.getSQLState() + "\n");
        resultText.append("VendorError:  " + e.getErrorCode() + "\n");
    }

    public Delete(){
    	
    	//connDb();
        loadProducts();


        ids.setBounds(50, 100, 200, 350);
        heading.setBounds(150, 50, 100, 20);
        Id.setBounds(300, 100, 100, 30);
        pName.setBounds(300, 150, 200, 30);
        tpId.setBounds(450, 100, 150, 30);
       	tpName.setBounds(450, 150, 150, 30);
        des.setBounds(300, 200, 150, 30);
        tDescription.setBounds(450, 200, 150, 30);
        dat.setBounds(300, 250, 150, 30);
        date.setBounds(450, 250,150, 30);
        course.setBounds(300, 300, 150, 30);
        tcourse.setBounds(450, 300, 150, 30);
        code.setBounds(300, 350, 150, 30);
        tcode.setBounds(450, 350, 150, 30);
        score.setBounds(300, 400, 150, 30);
        tscore.setBounds(450, 400, 150, 30);
        resultText.setBounds(300, 450, 300, 150);
   
      
       
        
        delete.setBounds(50, 470, 100, 30);
        go_to.setBounds(50, 500, 100, 30);
        home.setBounds(50, 550, 100, 30);
        back.setBounds(50, 600, 100, 30);
        
       // Color Blue = new Color(187, 255, 153);
   		//frame.getContentPane().setBackground(Blue);
        
        frame.add(ids);
        frame.add(heading);
        frame.add(Id);
        frame.add(pName);
        frame.add(tpId);
        frame.add(tpName);
        frame.add(dat);
       frame.add(date);
        frame.add(des);
        frame.add(tDescription);
        frame.add(course);
        frame.add(tcourse);
        frame.add(code);
        frame.add(tcode);
        frame.add(score);
        frame.add(tscore);
        frame.add(delete);
        frame.add(go_to);
        frame.add(home); 
        //frame.add(resultText);
        frame.add(back);
        
        frame.setLayout(null);  
        frame.setVisible(true);
        frame.setBounds(10, 10, 700, 700);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setResizable(true);  

        ids.addItemListener(new ItemListener() {
		public void itemStateChanged(ItemEvent ae) {
            
            try     
            {
				
			        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","shreya","vasavi123");
                    System.out.println("connection successful");
            	    ResultSet rs;
					PreparedStatement stmt = con.prepareStatement("SELECT * FROM addrecruiter where RECRUITER_ID ='"+ids.getSelectedItem()+"'");
					rs = stmt.executeQuery();
                    rs.next();
                    tpId.setText(String.valueOf(rs.getString(1)));
                    tpName.setText(rs.getString(2));
                    tDescription.setText(rs.getString(3));
                    date.setText(rs.getString(4));
                    tcourse.setText(rs.getString(5));
                    tcode.setText(rs.getString(6));
                    tscore.setText(String.valueOf(rs.getString(7)));

                } 
                catch (SQLException selectException) 
                {
                    displaySQLErrors(selectException);
                }
        }});

        delete.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent ae) {
            try 
                {   
				    Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","shreya","vasavi123");
				    PreparedStatement stmt = con.prepareStatement("DELETE FROM addrecruiter WHERE RECRUITER_ID = " + ids.getSelectedItem());//SELECT * FROM addrecruiter where Recruiter_ID ='"+ids.getSelectedItem(
                    int i = stmt.executeUpdate(); 
					if(i>0)
					{
						JOptionPane.showMessageDialog(new JFrame(),"Successfully Deleted!","NOTICE",JOptionPane.INFORMATION_MESSAGE); 
                    //resultText.append("\nUpdated " + i + " rows successfully");
					}
					
                    //resultText.append("\nDeleted " + i + " rows successfully");
                    ids.removeAll();
                    loadProducts();
                } 
                catch (SQLException insertException) 
                {
                    displaySQLErrors(insertException);
                }   
         
        }});

        home.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent ae) {
            frame.dispose();
            new HomePage1();
            // new clickListener();
         
        }});
        
        back.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
               frame.dispose();
              // new admChoice();
               // new clickListener();
               new Admin1();
            
           }});
   
    }   
}