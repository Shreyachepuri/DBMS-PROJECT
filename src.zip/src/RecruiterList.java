import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;
public class AddRecruiter2 implements ActionListener{
	private JFrame f=new JFrame("ADD RECRUITER");
	private JLabel l=new JLabel("");
	private JLabel l1=new JLabel("Enter cid,username,password,name,email,contact,website to insert");
	private JLabel l2=new JLabel("Enter cid,username,password,name,email,contact,website to update");
	private JLabel l3=new JLabel("Enter cid to delete");
	private JLabel l4=new JLabel("Result");
	private JLabel l5=new JLabel("ADD RECRUITER");
	private JButton b1=new JButton("SUBMIT");
	private JButton b2=new JButton("MODIFY");
	private JButton b3=new JButton("DELETE");
	private JTextField t1=new JTextField();
	private JTextField t2=new JTextField();
	private JTextField t3=new JTextField();
	private JTextField t=new JTextField();
	public AddRecruiter2() {
		f.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		f.setBounds(100,150,1000,400);
		Container c=f.getContentPane();
		f.getContentPane().add(l1);
		f.getContentPane().add(l2);
		f.getContentPane().add(l3);
		f.getContentPane().add(l4);
		f.getContentPane().add(l5);
		f.getContentPane().add(b1);
		f.getContentPane().add(b2);
		f.getContentPane().add(b3);
		f.getContentPane().add(t1);
		f.getContentPane().add(t2);
		f.getContentPane().add(t3);
		f.getContentPane().add(t);
		l.setBounds(20,30,50,50);
		l1.setBounds(80,80,500,30);
		l1.setOpaque(true);
		l2.setBounds(80,120,500,30);
		l2.setOpaque(true);
		l3.setBounds(80,160,500,30);
		l3.setOpaque(true);
		l4.setBounds(80,200,250,30);
		l4.setOpaque(true);
		l5.setBounds(430,5,700,50);	
        l5.setFont(new Font("Serif",Font.PLAIN,30));		
		b1.setBounds(60,250,150,30);
		b1.setFont(new Font("Times New Roman",Font.BOLD,17));
		b2.setBounds(300,250,150,30);
		b2.setFont(new Font("Times New Roman",Font.BOLD,17));
		b3.setBounds(540,250,150,30);
		b3.setFont(new Font("Times New Roman",Font.BOLD,17));
		t1.setBounds(600,80,220,30);
		t2.setBounds(600,120,220,30);
		t3.setBounds(600,160,220,30);
		t.setBounds(600,200,220,30);
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		c.add(l);
		f.setVisible(true);
	}
	public void actionPerformed(ActionEvent ae){
		String s=new String(ae.getActionCommand());
		if((s).equals("SUBMIT")){
			try{
				t.setText("1 row Inserted "+t1.getText());
				Class.forName("oracle.jdbc.OracleDriver");
				Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","shreya","vasavi123");
				Statement stmt=con.createStatement();
				StringTokenizer st=new StringTokenizer(t1.getText(),",");
                int company_id = Integer.parseInt(st.nextToken());
				String username = st.nextToken();
				String password=st.nextToken();
				String name=st.nextToken();
				String email=st.nextToken();
				int contact=Integer.parseInt(st.nextToken());
				String website=st.nextToken();
				stmt.executeUpdate("insert into Company values("+company_id+",'"+username+"','"+password+"','"+name+"' ,'"+email+"',"+contact+",'"+website+"')");
				con.close();
		}
		catch (Exception e) {
			System.out.println(e);
			t.setText("Error Occured!!");
		}
			t2.setText("");
			t3.setText("");
		}
		else if((s).equals("MODIFY")){
			try{
				t.setText("1 row Updated "+t2.getText());
				Class.forName("oracle.jdbc.OracleDriver");
				Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","shreya","vasavi123");
				Statement stmt=con.createStatement();
				StringTokenizer st=new StringTokenizer(t2.getText(),",");
                int company_id = Integer.parseInt(st.nextToken());
				String username = st.nextToken();
				String password=st.nextToken();
				String name=st.nextToken();
				String email=st.nextToken();
				int contact=Integer.parseInt(st.nextToken());
				String website=st.nextToken();
				stmt.executeUpdate("Update Company set username='"+username+"',password='"+password+"',name='"+name+"' ,contact="+contact+",website='"+website+"',where company_id="+company_id+"");
				con.close();
			}
			catch(Exception e){
				t.setText("Error Occured!!");
			}
			t1.setText("");
			t3.setText("");
		}
		else if((s).equals("DELETE")){
			try{
				t.setText("Deleted 1 row with cid "+t3.getText());
				Class.forName("oracle.jdbc.OracleDriver");
				Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","shreya","vasavi123");
				Statement stmt=con.createStatement();
				int company_id=Integer.parseInt(t3.getText());
				stmt.executeUpdate("delete from company where company_id="+company_id+"");
			    con.close();
			}
			catch(Exception e){
				t.setText("Error Occured!!");
			}
			t1.setText("");
			t2.setText("");
	    }
			
	}
	public static void main(String[] args){
		new AddRecruiter2();
	}
}