import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.table.*;
import java.sql.*;
public class Job_List_seeker extends JFrame {
	
	 DefaultTableModel model = new DefaultTableModel();
     JFrame frame = new JFrame();
	 JTable jtbl = new JTable(model);
	 
	    public Job_List_seeker() {
	        frame.setLayout(new FlowLayout(FlowLayout.LEFT));
	        model.addColumn("Job ID");
	        model.addColumn("Job title");
	        model.addColumn("Job Description");
	        model.addColumn("Category ID");
	        model.addColumn("Company ID");
	        model.addColumn("Type");
			model.addColumn("Salary");
			model.addColumn("Posting Date");
			model.addColumn("Last Date");
			model.addColumn("No of Vacancies");
			model.addColumn("Status");
	        
			jtbl.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
			jtbl.getColumnModel().getColumn(0).setPreferredWidth(70);
			jtbl.getColumnModel().getColumn(1).setPreferredWidth(100);
			jtbl.getColumnModel().getColumn(2).setPreferredWidth(150);
			jtbl.getColumnModel().getColumn(3).setPreferredWidth(90);
			jtbl.getColumnModel().getColumn(4).setPreferredWidth(70);
			jtbl.getColumnModel().getColumn(5).setPreferredWidth(150);
			jtbl.getColumnModel().getColumn(6).setPreferredWidth(100);
			jtbl.getColumnModel().getColumn(7).setPreferredWidth(150);
			jtbl.getColumnModel().getColumn(8).setPreferredWidth(190);
			jtbl.getColumnModel().getColumn(9).setPreferredWidth(70);
			jtbl.getColumnModel().getColumn(10).setPreferredWidth(190);
			
	        String dburl ="jdbc:oracle:thin:@localhost:1521:xe";
			String us = "shreya";
			String pas ="vasavi123";
	        try {
	        	Connection  conn=DriverManager.getConnection(dburl,us,pas);
				System.out.println("Connected");
	            PreparedStatement pstm = conn.prepareStatement("SELECT * FROM Job_information");
	            ResultSet Rs = pstm.executeQuery();
	            while(Rs.next()){
	                model.addRow(new Object[]{Rs.getInt(1), Rs.getString(2),Rs.getString(3),Rs.getInt(4),Rs.getInt(5),Rs.getString(6),Rs.getInt(7),Rs.getDate(8),Rs.getDate(9),Rs.getInt(10),Rs.getString(11)});
	            }
	        } catch (Exception e) {
	            System.out.println(e.getMessage());
	        }
			
	        JScrollPane pg = new JScrollPane(jtbl);
			JButton apply = new JButton("APPLY");
		    pg.setBounds(10,10,2000,300);
			frame.add(pg);
			apply.setBounds(50,350,150,50);
			
			frame.add(apply);
			
			frame.setLayout(null);  
            frame.setVisible(true);
            frame.setBounds(10, 10, 600, 600);
            frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
            frame.setResizable(true);
			
	        pg.createHorizontalScrollBar();
	        pg.createVerticalScrollBar();
	        this.pack();
	        
			
			apply.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				try {
					
					
					
					int row=jtbl.getSelectedRow();
					String job_id = jtbl.getModel().getValueAt(row,0).toString();
					String job_title = jtbl.getModel().getValueAt(row,1).toString();
					String job_description = jtbl.getModel().getValueAt(row,2).toString();
					String cat_id = jtbl.getModel().getValueAt(row,3).toString();
					String comp_id = jtbl.getModel().getValueAt(row,4).toString();
					String type = jtbl.getModel().getValueAt(row,5).toString();
					String salary = jtbl.getModel().getValueAt(row,6).toString();
					String posting_date = jtbl.getModel().getValueAt(row,7).toString();
					String last_date = jtbl.getModel().getValueAt(row,8).toString();
					String no_of_vac = jtbl.getModel().getValueAt(row,9).toString();
					String status = jtbl.getModel().getValueAt(row,10).toString();
					
	        	    Connection  conn=DriverManager.getConnection(dburl,us,pas);
				    System.out.println("Connected");
	                PreparedStatement stmt = conn.prepareStatement("insert into Applied_Job_List values(?,?,?,?,?,?,?,?,?,?,?)");
					stmt.setInt(1,Integer.parseInt(job_id));	
                    stmt.setString(2,job_title);	
                    stmt.setString(3,job_description);	
                    stmt.setInt(4,Integer.parseInt(cat_id));	
                    stmt.setInt(5,Integer.parseInt(comp_id));	
                    stmt.setString(6,type);	
                    stmt.setInt(7,Integer.parseInt(salary));
					Date date = Date.valueOf(posting_date);
					stmt.setDate(8,date);
					Date date1 = Date.valueOf(last_date);
					stmt.setDate(9,date1);
					stmt.setInt(10,Integer.parseInt(no_of_vac));
					stmt.setString(11,status);
					
					int i=stmt.executeUpdate();
                    System.out.println(i + "records inserted");	
					if(i>0)
					{
						JOptionPane.showMessageDialog(new JFrame(),"Successfully APPLIED!","NOTICE",JOptionPane.INFORMATION_MESSAGE); 
					}
					
					conn.close();
					} 
					catch (Exception e) {
						System.out.println(e.getMessage());
	                }
				}
				
				
		   });
	    }
}