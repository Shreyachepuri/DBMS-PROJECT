import java.sql.*;
public class TrialConnect{
	public static void main(String[] args){
		try{
			Class.forName("oracle.jdbc.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","shreya","vasavi123");
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select * from vasavi");
			while(rs.next())  
				System.out.println(rs.getString(1)+"  "+rs.getString(2));
			con.close();
		}
		catch(Exception e){
			System.out.println(e);
		}
	}
}