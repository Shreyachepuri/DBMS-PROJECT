import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.*;
import java.sql.*;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class JobseekerLogin extends JFrame {

    private static final long serialVersionUID = 1L;
    private JTextField textField;
    private JPasswordField passwordField;
    private JButton btnNewButton;
    private JLabel label;
    private JPanel contentPane;
	JFrame frame = new JFrame();
                    

    

    /**
     * Create the frame.
     */
    public JobseekerLogin() {
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        setBounds(50,30,500,500);
		setVisible(true);
        setResizable(true);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("Login");
        lblNewLabel.setForeground(Color.BLACK);
        lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 35));
        lblNewLabel.setBounds(200, 13, 273, 93);
        contentPane.add(lblNewLabel);

        textField = new JTextField();
        //textField.setFont(new Font("Tahoma", Font.PLAIN, 20));
        textField.setBounds(200, 150, 80,30);
        contentPane.add(textField);
        textField.setColumns(10);

        passwordField = new JPasswordField();
        //passwordField.setFont(new Font("Tahoma", Font.PLAIN, 20));
        passwordField.setBounds(200, 200, 80, 30);
        contentPane.add(passwordField);

        JLabel lblUsername = new JLabel("Username");
        lblUsername.setBackground(Color.BLACK);
        lblUsername.setForeground(Color.BLACK);
        //lblUsername.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblUsername.setBounds(100, 150, 80,30);
        contentPane.add(lblUsername);

        JLabel lblPassword = new JLabel("Password");
        lblPassword.setForeground(Color.BLACK);
        lblPassword.setBackground(Color.CYAN);
        //lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 10));
        lblPassword.setBounds(100,200, 80,30);
        contentPane.add(lblPassword);

        btnNewButton = new JButton("Login");
        //btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 10));
        btnNewButton.setBounds(150,300,80,30);
        btnNewButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                String userName = textField.getText();
                String password = passwordField.getText();
				
				String dburl ="jdbc:oracle:thin:@localhost:1521:xe";
			    String us = "shreya";
			    String pas ="vasavi123";
                try {
					Connection  connection=DriverManager.getConnection(dburl,us,pas);
				    System.out.println("Connected");
                    

                    PreparedStatement st = (PreparedStatement) connection.prepareStatement("Select username, password from jobseekerlogin where username=? and password=?");

                    st.setString(1, userName);
                    st.setString(2, password);
                    ResultSet rs = st.executeQuery();
                    if (rs.next()) {
                        
                        JOptionPane.showMessageDialog(btnNewButton, "You have successfully logged in");
						frame.dispose();
						new Jobseeker1();
                    } else {
                        JOptionPane.showMessageDialog(btnNewButton, "Wrong Username & Password");
                    }
                } catch (SQLException sqlException) {
                    sqlException.printStackTrace();
                }
            }
        });

        contentPane.add(btnNewButton);

        label = new JLabel("");
        label.setBounds(0, 0, 1008, 562);
        contentPane.add(label);
		add(contentPane);
    }
}