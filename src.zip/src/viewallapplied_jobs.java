import java.awt.*;

import javax.swing.*;

public class viewallapplied_jobs {
	
	viewallapplied_jobs(){
	
		JFrame frame = new applied_jobs_list();
		
        frame.setTitle("Applied Jobs List");
        frame.setSize(5000, 3000);
        frame.setLocationRelativeTo(null);
		frame.pack();
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE); 
	    
	}
}