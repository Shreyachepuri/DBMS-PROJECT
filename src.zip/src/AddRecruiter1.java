import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import javax.swing.*;


public class AddRecruiter1
{
    JFrame frame = new JFrame("Insert");

    JLabel heading = new JLabel("ADD RECRUITER");

    JLabel Rid = new JLabel("Recruiter ID : ");
    JLabel user = new JLabel("User Name :");
    JLabel ps = new JLabel("Password : ");
    JLabel comp = new JLabel("Company Name: ");
    JLabel email = new JLabel("Email : ");
    JLabel web = new JLabel("Website : ");
	JLabel cont = new JLabel("Contact : ");
    JLabel go_to = new JLabel("GOTO");

    JTextField tfId = new JTextField();
    JTextField tfuserName = new JTextField();
    JPasswordField tfps = new JPasswordField();
	JTextField tfcompName = new JTextField();
    JTextField tfem = new JTextField();
    JTextField tfweb = new JTextField();
	JTextField tfcont = new JTextField();
    JTextArea resultText = new JTextArea();
    
    JButton home = new JButton("Home");
    JButton insert = new JButton("Submit");
    JButton back = new JButton("Back");

    PreparedStatement stmt;
   

    public AddRecruiter1(){
    	
    	


        heading.setBounds(50, 50, 100, 20);
        Rid.setBounds(50, 100, 130, 30);
        user.setBounds(50, 150, 200, 30);
        tfId.setBounds(250, 100, 150, 30); 
       	tfuserName.setBounds(250, 150, 150, 30);
        ps.setBounds(50, 200, 150, 30);
        tfps.setBounds(250, 200, 150, 30);
		tfps.setEchoChar('*');
        comp.setBounds(50, 250, 150, 30);
        tfcompName.setBounds(250, 250,150, 30);
        email.setBounds(50, 300, 150, 30);
        tfem.setBounds(250, 300, 150, 30);
        web.setBounds(50, 350, 150, 30);
        tfweb.setBounds(250, 350, 150, 30);
        cont.setBounds(50, 400, 150, 30);
        tfcont.setBounds(250, 400, 150, 30);
        resultText.setBounds(250, 450, 200, 150);
        
        insert.setBounds(50, 450, 100, 30);
        go_to.setBounds(50, 500, 100, 30);
        home.setBounds(50, 550, 100, 30);
        back.setBounds(50, 600, 100, 30);

        frame.add(heading);
        frame.add(Rid);
        frame.add(user);
        frame.add(tfId);
        frame.add(tfuserName);
        frame.add(ps);
        frame.add(tfps);
        frame.add(comp);
        frame.add(tfcompName);
        frame.add(email);
        frame.add(tfem);
        frame.add(web);
        frame.add(tfweb);
        frame.add(cont);
        frame.add(tfcont);
        frame.add(insert);
        frame.add(go_to);
        frame.add(home); 
        //frame.add(resultText);
        frame.add(back);
        
        frame.setLayout(null);  
        frame.setVisible(true);
        frame.setBounds(10, 10, 500, 700);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setResizable(false);  

        insert.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent ae) {
            
            try {	
			  
                    
				    Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","shreya","vasavi123");
				    PreparedStatement stmt=con.prepareStatement("insert into Addrecruiter values(?,?,?,?,?,?,?)");
					if(tfId.getText()=="");
					{
						JOptionPane.showMessageDialog(new JFrame(),"Please Insert values!","NOTICE",JOptionPane.INFORMATION_MESSAGE);
					}
					
						stmt.setInt(1,Integer.parseInt(tfId.getText()));	
						stmt.setString(2,tfuserName.getText());	
						stmt.setString(3,tfps.getText());	
						stmt.setString(4,tfcompName.getText());	
						stmt.setString(5,tfem.getText());	
						stmt.setString(6,tfweb.getText());	
						stmt.setInt(7,Integer.parseInt(tfcont.getText()));
										
                    int i=stmt.executeUpdate();
					if(i>0)
					{
						JOptionPane.showMessageDialog(new JFrame(),"Successfully Inserted!","NOTICE",JOptionPane.INFORMATION_MESSAGE); 
					}
                    /*System.out.println(i + "records inserted");	
					resultText.append("Inserted" + i + "rows successfully"); */
					con.close();
                    
	                 
	             
            }
            catch(SQLException e){
                System.out.println(e);
            }
            

            
        }});

        home.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent ae) {
            frame.dispose();
            new HomePage1();
            
         
        }});
        
        back.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
               frame.dispose();
               new Admin1();
              
            
           }});
   
    }   
}



