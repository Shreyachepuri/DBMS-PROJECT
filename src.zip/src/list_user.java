import javax.swing.*;
import java.awt.*;
import javax.swing.table.*;
import java.sql.*;
import java.awt.event.*;
public class list_user extends JFrame {
	 JFrame frame = new JFrame();
	 DefaultTableModel model = new DefaultTableModel();
	 JTable jtbl = new JTable(model);
	 
	    public list_user() {
	        frame.setLayout(new FlowLayout(FlowLayout.LEFT));
	        
	        model.addColumn("Name");
	        model.addColumn("Email");
	        model.addColumn("Contact");
	        model.addColumn("Gender");
	        model.addColumn("skills");
			model.addColumn("qualification");
			model.addColumn("Work Experience");
	        
			jtbl.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
			jtbl.getColumnModel().getColumn(0).setPreferredWidth(70);
			jtbl.getColumnModel().getColumn(1).setPreferredWidth(100);
			jtbl.getColumnModel().getColumn(2).setPreferredWidth(150);
			jtbl.getColumnModel().getColumn(3).setPreferredWidth(90);
			jtbl.getColumnModel().getColumn(4).setPreferredWidth(70);
			jtbl.getColumnModel().getColumn(5).setPreferredWidth(150);
			jtbl.getColumnModel().getColumn(6).setPreferredWidth(200);
			
	        String dburl ="jdbc:oracle:thin:@localhost:1521:xe";
			String us = "shreya";
			String pas ="vasavi123";
	        try {
	        	Connection  conn=DriverManager.getConnection(dburl,us,pas);
				System.out.println("Connected");
	            
	            PreparedStatement pstm = conn.prepareStatement("SELECT * FROM jobseeker1");
	            ResultSet Rs = pstm.executeQuery();
	            while(Rs.next()){
	                model.addRow(new Object[]{Rs.getString(1), Rs.getString(2),Rs.getLong(3),Rs.getString(4),Rs.getString(5),Rs.getString(6),Rs.getString(7)});
	            }
	        } catch (Exception e) {
	            System.out.println(e.getMessage());
	        }
			
	        JScrollPane pg = new JScrollPane(jtbl);
			JButton upd = new JButton("Update");
			JButton dlt = new JButton("Delete");
	        pg.setBounds(10,10,400,400);
	        pg.createHorizontalScrollBar();
	        pg.createVerticalScrollBar();
			
	        frame.add(pg);
	        
			upd.setBounds(50,450,150,50);
			dlt.setBounds(300,450,150,50);
			
			
			frame.setLayout(null);  
            frame.setVisible(true);
            frame.setBounds(10, 10, 600, 600);
            frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
            frame.setResizable(true);
			
	        
	    }
}