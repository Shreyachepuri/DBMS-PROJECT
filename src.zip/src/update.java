import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class update
{
    JFrame frame = new JFrame("Update Recruiters list");

    JLabel heading = new JLabel("UPDATE RECRUITERS LIST");

    JLabel Id = new JLabel("Recruiter ID : ");
    JLabel pName = new JLabel("User Name :");
    JLabel des = new JLabel("Password : ");
    JLabel dat = new JLabel("Company Name : ");
    JLabel course = new JLabel("Email : ");
    JLabel code = new JLabel("Website : ");
    JLabel score = new JLabel("Contact: ");
    JLabel go_to = new JLabel("GOTO");
    

    List ids = new List(15);

    JTextField tpId = new JTextField();
    JTextField tpName = new JTextField();
    JTextField tscore = new JTextField();
    JTextField date = new JTextField();
    JTextField tcourse = new JTextField();
    JTextField tcode = new JTextField();
    JTextField tDescription = new JTextField();
    
    JTextArea resultText = new JTextArea();
    
    JButton home = new JButton("HOME");
    JButton update = new JButton("MODIFY");
    JButton back = new JButton("BACK");

    Statement stmt;
    
    public void connDb() {
    	try{
           
        
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","shreya","vasavi123");
            stmt = con.createStatement();
            System.out.println("connection successful");
//            
        }
        catch(SQLException e){
            System.out.println(e);
        }
    }

    public void loadProducts(){

        try 
        {
		  Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","shreya","vasavi123");
          ResultSet rs;
		  PreparedStatement stmt = con.prepareStatement("SELECT Recruiter_ID FROM addrecruiter");
          rs = stmt.executeQuery();
          
          while (rs.next()) 
          {
            ids.add(rs.getString(1));
          }
        } 
        catch (SQLException e) 
        { 
          displaySQLErrors(e);
        }
    }
    private void displaySQLErrors(SQLException e) 
    {
        JOptionPane.showMessageDialog(frame,"Enter valid data types");  
        resultText.append("\nSQLException: " + e.getMessage() + "\n");
        resultText.append("SQLState:     " + e.getSQLState() + "\n");
        resultText.append("VendorError:  " + e.getErrorCode() + "\n");
    }

    public update(){
    	
    	connDb();
        loadProducts();

        ids.setBounds(50, 100, 200, 350);
        heading.setBounds(150, 50, 100, 20);
        Id.setBounds(300, 100, 100, 30);
        pName.setBounds(300, 150, 200, 30);
        tpId.setBounds(450, 100, 150, 30);
       	tpName.setBounds(450, 150, 150, 30);
        des.setBounds(300, 200, 150, 30);
        tDescription.setBounds(450, 200, 150, 30);
        dat.setBounds(300, 250, 150, 30);
        date.setBounds(450, 250,150, 30);
        course.setBounds(300, 300, 150, 30);
        tcourse.setBounds(450, 300, 150, 30);
        code.setBounds(300, 350, 150, 30);
        tcode.setBounds(450, 350, 150, 30);
        score.setBounds(300, 400, 150, 30);
        tscore.setBounds(450, 400, 150, 30);
        resultText.setBounds(300, 450, 300, 150);
   
      
        
        update.setBounds(50, 470, 100, 30);
        go_to.setBounds(50, 500, 100, 30);
        home.setBounds(50, 550, 100, 30);
        back.setBounds(50, 600, 100, 30);
        
        frame.add(ids);
        frame.add(heading);
        frame.add(Id);
        frame.add(pName);
        frame.add(tpId);
        frame.add(tpName);
        frame.add(dat);
        frame.add(date);
        frame.add(des);
        frame.add(tDescription);
        frame.add(course);
        frame.add(tcourse);
        frame.add(code);
        frame.add(tcode);
        frame.add(score);
        frame.add(tscore);
        frame.add(update);
        frame.add(go_to);
        frame.add(home); 
        //frame.add(resultText);
        frame.add(back);
        
        frame.setLayout(null);  
        frame.setVisible(true);
        frame.setBounds(10, 10, 700, 700);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setResizable(false);  

        ids.addItemListener(new ItemListener() {
		public void itemStateChanged(ItemEvent ae) {
            
            try     
            {
				    Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","shreya","vasavi123");
                    System.out.println("connection successful");
            	    ResultSet rs;
					PreparedStatement stmt = con.prepareStatement("SELECT * FROM addrecruiter where RECRUITER_ID ='"+ids.getSelectedItem()+"'");
					rs = stmt.executeQuery();
                    rs.next();
                    tpId.setText(String.valueOf(rs.getString(1)));
                    tpName.setText(rs.getString(2));
                    tDescription.setText(rs.getString(3));
                    date.setText(rs.getString(4));
                    tcourse.setText(rs.getString(5));
                    tcode.setText(rs.getString(6));
                    tscore.setText(String.valueOf(rs.getString(7)));
            	    
                } 
                catch (SQLException selectException) 
                {
                    displaySQLErrors(selectException);
                }
        }});

        update.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent ae) {
            try 
                {   

                   
                    int i = stmt.executeUpdate("UPDATE addrecruiter "
                    + "SET RECRUITER_ID=" + tpId.getText() + ", "
                    + "USERNAME='" + tpName.getText() + "', "
                    + "PASSWORD= '" + tDescription.getText() + "', "
                    + "COMPANY_NAME='" + date.getText() + "', "
                    + "EMAIL='" + tcourse.getText() + "', "
                    + "WEBSITE='" + tcode.getText() + "', "
                    + "CONTACT ="+ tscore.getText() + " WHERE recruiter_id = "
                    + ids.getSelectedItem());
                    if(i>0)
					{
						JOptionPane.showMessageDialog(new JFrame(),"Successfully Updated!","NOTICE",JOptionPane.INFORMATION_MESSAGE); 
                    
					}
                    ids.removeAll();
                    loadProducts();
                } 
                catch (SQLException insertException) 
                {
                    displaySQLErrors(insertException);
                }   
         
        }});

        home.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent ae) {
            frame.dispose();
            new HomePage1();
            
         
        }});
        
        back.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
               frame.dispose();
               new Admin1();
               
            
           }});
   
    }   
}