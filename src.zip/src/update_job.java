import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class update_job
{
    JFrame frame = new JFrame("Update Job");

    JLabel heading = new JLabel("UPDATE Job");
	
	JLabel l1 = new JLabel("Job ID : ");
    JLabel l2 = new JLabel("Job Title :");
    JLabel l3= new JLabel("Job Description : ");
    JLabel l4 = new JLabel("Category Id: ");
    JLabel l5 = new JLabel("Company Id : ");
    JLabel l6 = new JLabel("Type : ");
	JLabel l7 = new JLabel("Salary : ");
	JLabel l8 = new JLabel("Posting Date : ");
	JLabel l9 = new JLabel("Last Date : ");
	JLabel l10 = new JLabel("No of Vacancies : ");
	JLabel l11 = new JLabel("Status : ");
    JLabel go_to = new JLabel("GOTO");

   
    

    List ids = new List(15);
	
	JTextField tf1 = new JTextField();
    JTextField tf2 = new JTextField();
    JTextField tf3 = new JTextField();
	JTextField tf4 = new JTextField();
    JTextField tf5 = new JTextField();
    JTextField tf6 = new JTextField();
	JTextField tf7 = new JTextField();
	JTextField tf8 = new JTextField();
	JTextField tf9 = new JTextField();
	JTextField tf10 = new JTextField();
	JTextField tf11= new JTextField();
    JTextArea resultText = new JTextArea();
    

    
    
    JButton home = new JButton("Home");
    JButton update = new JButton("MODIFY");
    JButton back = new JButton("Back");

    PreparedStatement stmt;
    
    public void connDb() {
    	try{
            //Class.forName("oracle.jdbc.driver.OracleDriver");
        
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","shreya","vasavi123");
            //stmt = con.createStatement();
            System.out.println("connection successful");
//            con.close();
        }
        catch(SQLException e){
            System.out.println(e);
        }
    }

    public void loadProducts(){

        try 
        {
		  Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","shreya","vasavi123");
          ResultSet rs;
		  PreparedStatement stmt = con.prepareStatement("SELECT job_ID FROM job_information");
          rs = stmt.executeQuery();
          
          while (rs.next()) 
          {
            ids.add(rs.getString(1));
          }
        } 
        catch (SQLException e) 
        { 
          displaySQLErrors(e);
        }
    }
    private void displaySQLErrors(SQLException e) 
    {
        JOptionPane.showMessageDialog(frame,"Enter valid data types");  
        resultText.append("\nSQLException: " + e.getMessage() + "\n");
        resultText.append("SQLState:     " + e.getSQLState() + "\n");
        resultText.append("VendorError:  " + e.getErrorCode() + "\n");
    }

    public update_job(){
    	
    	connDb();
        loadProducts();

        ids.setBounds(50, 300, 200,250);
		
		heading.setBounds(50, 50, 100, 20);
        l1.setBounds(50, 100, 130, 30);
        l2.setBounds(50, 150, 200, 30);
        tf1.setBounds(250, 100, 150, 30); 
       	tf2.setBounds(250, 150, 150, 30);
        l3.setBounds(50, 200, 150, 30);
        tf3.setBounds(250, 200, 150, 30);
        l4.setBounds(50, 250, 150, 30);
        tf4.setBounds(250, 250,150, 30);
		
        l5.setBounds(500, 100, 150, 30);
        tf5.setBounds(650, 100, 150, 30);
		
        l6.setBounds(500, 150, 150, 30);
        tf6.setBounds(650, 150, 150, 30);
		
		l7.setBounds(500, 200, 150, 30);
        tf7.setBounds(650, 200, 150, 30);
		
		l8.setBounds(500, 250, 150, 30);
        tf8.setBounds(650, 250, 150, 30);
		
		l9.setBounds(500, 300, 150, 30);
        tf9.setBounds(650, 300, 150, 30);
		
		l10.setBounds(500, 350, 150, 30);
        tf10.setBounds(650, 350, 150, 30);
		
		l11.setBounds(500, 400, 150, 30);
        tf11.setBounds(650, 400, 150, 30);
		
		update.setBounds(750, 500, 150, 30);
        
        resultText.setBounds(50, 300, 200, 150);
        
        
        
        //Color Blue = new Color(187, 255, 153);
		//frame.getContentPane().setBackground(Blue);
		
		frame.add(heading);
        frame.add(l1);
        frame.add(l2);
        frame.add(tf1);
        frame.add(tf2);
        frame.add(l3);
        frame.add(tf3);
        frame.add(l4);
        frame.add(tf4);
        frame.add(l5);
        frame.add(tf5);
        frame.add(l6);
        frame.add(tf6);
		
		frame.add(l7);
        frame.add(tf7);
		
		frame.add(l8);
        frame.add(tf8);
		
		frame.add(l9);
        frame.add(tf9);
		
		frame.add(l10);
        frame.add(tf10);
		
		frame.add(l11);
        frame.add(tf11);

        frame.add(ids);
        frame.add(update);
        frame.add(go_to);
        frame.add(home); 
        frame.add(resultText);
        frame.add(back);
        
        frame.setLayout(null);  
        frame.setVisible(true);
        frame.setBounds(10, 10, 700, 700);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setResizable(true);  

        ids.addItemListener(new ItemListener() {
		public void itemStateChanged(ItemEvent ae) {
            
            try     
            {
				    Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","shreya","vasavi123");
                    System.out.println("connection successful");
            	    ResultSet rs;
					PreparedStatement stmt = con.prepareStatement("SELECT * FROM job_information where job_ID ='"+ids.getSelectedItem()+"'");
					rs = stmt.executeQuery();
                    rs.next();
                    tf1.setText(rs.getString(1));
                    tf2.setText(rs.getString(2));
                    tf3.setText(rs.getString(3));
                    tf4.setText(rs.getString(4));
                    tf5.setText(rs.getString(5));
                    tf6.setText(rs.getString(6));
                    tf7.setText(rs.getString(7));
					tf8.setText(rs.getString(8));
					tf9.setText(rs.getString(9));
					tf10.setText(rs.getString(10));
					tf11.setText(rs.getString(11));
            	    
                } 
                catch (SQLException selectException) 
                {
                    displaySQLErrors(selectException);
                }
        }});

        update.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent ae) {
            try 
                {   

//                    Statement statement = con.createStatement();
                     JOptionPane.showMessageDialog(new JFrame(),"Successfully Updated!","NOTICE",JOptionPane.INFORMATION_MESSAGE); 
                    int i = stmt.executeUpdate("UPDATE job_information SET JOB_ID=" + tf1.getText() + ",JOB_TITLE='" + tf2.getText() + "',JOB_DESCRIPTION= '" + tf3.getText() + "',CATEGORY_ID=" + tf4.getText() + ", COMPANY_ID=" + tf5.getText() + ", "
					+ "TYPE='" + tf6.getText() + "', "
                    + "SALARY ="+ tf7.getText() + ","
					+ "POSTING_DATE ="+ tf8.getText() + ","
					+  "LAST_DATE ="+ tf9.getText() + ","
					+ "NO_OF_VACANCIES ="+ tf10.getText()+"," 
					+ "STATUS ='"+ tf11.getText()+ "',"
					+"WHERE JOB_ID = "+ ids.getSelectedItem());
                    //if(i>0)
					//{
						//JOptionPane.showMessageDialog(new JFrame(),"Successfully Updated!","NOTICE",JOptionPane.INFORMATION_MESSAGE); 
                        resultText.append("\nUpdated " + i + " rows successfully");
					//}
                    //resultText.append("\nUpdated " + i + " rows successfully");
                    ids.removeAll();
                    loadProducts();
                } 
                catch (SQLException e) 
                {
                    displaySQLErrors(e);
                }   
         
        }});

        home.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent ae) {
            frame.dispose();
            new HomePage1();
            // new clickListener();
         
        }});
        
        back.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
               frame.dispose();
               new Admin1();
               // new clickListener();
            
           }});
   
    }   
}