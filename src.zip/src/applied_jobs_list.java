import javax.swing.*;
import java.awt.*;
import javax.swing.table.*;
import java.sql.*;
public class applied_jobs_list extends JFrame {
	
	 DefaultTableModel model = new DefaultTableModel();
     Container cnt = new Container();
	 JTable jtbl = new JTable(model);
	 
	 
	    public applied_jobs_list() {
	        cnt.setLayout(new FlowLayout(FlowLayout.LEFT));
	        model.addColumn("Job ID");
	        model.addColumn("Job title");
	        model.addColumn("Job Description");
	        model.addColumn("Category ID");
	        model.addColumn("Company ID");
	        model.addColumn("Type");
			model.addColumn("Salary");
			model.addColumn("Posting Date");
			model.addColumn("Last Date");
			model.addColumn("No of Vacancies");
			model.addColumn("Status");
	        
			jtbl.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
			jtbl.getColumnModel().getColumn(0).setPreferredWidth(70);
			jtbl.getColumnModel().getColumn(1).setPreferredWidth(100);
			jtbl.getColumnModel().getColumn(2).setPreferredWidth(150);
			jtbl.getColumnModel().getColumn(3).setPreferredWidth(90);
			jtbl.getColumnModel().getColumn(4).setPreferredWidth(70);
			jtbl.getColumnModel().getColumn(5).setPreferredWidth(150);
			jtbl.getColumnModel().getColumn(6).setPreferredWidth(100);
			jtbl.getColumnModel().getColumn(7).setPreferredWidth(150);
			jtbl.getColumnModel().getColumn(8).setPreferredWidth(190);
			jtbl.getColumnModel().getColumn(9).setPreferredWidth(70);
			jtbl.getColumnModel().getColumn(10).setPreferredWidth(190);
			
	        String dburl ="jdbc:oracle:thin:@localhost:1521:xe";
			String us = "shreya";
			String pas ="vasavi123";
	        try {
	        	Connection  conn=DriverManager.getConnection(dburl,us,pas);
				System.out.println("Connected");
	            PreparedStatement pstm = conn.prepareStatement("SELECT * FROM applied_job_list");
	            ResultSet Rs = pstm.executeQuery();
	            while(Rs.next()){
	                model.addRow(new Object[]{Rs.getInt(1), Rs.getString(2),Rs.getString(3),Rs.getInt(4),Rs.getInt(5),Rs.getString(6),Rs.getInt(7),Rs.getDate(8),Rs.getDate(9),Rs.getInt(10),Rs.getString(11)});
	            }
	        } catch (Exception e) {
	            System.out.println(e.getMessage());
	        }
			
	        JScrollPane pg = new JScrollPane(jtbl);
	        pg.setBounds(200,200,10000,10000);
			cnt.setSize(1000,1000);
	        pg.createHorizontalScrollBar();
	        pg.createVerticalScrollBar();
	        cnt.add(pg);
	        this.pack();
	        this.add(cnt);
	    }
}