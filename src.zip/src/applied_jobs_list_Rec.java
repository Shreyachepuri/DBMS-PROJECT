import javax.swing.*;
import java.awt.*;
import javax.swing.table.*;
import java.sql.*;
public class applied_jobs_list_Rec extends JFrame {
	
	 DefaultTableModel model = new DefaultTableModel();
     Container cnt = new Container();
	 JTable jtbl = new JTable(model);
	 
	 
	    public applied_jobs_list_Rec() {
	        cnt.setLayout(new FlowLayout(FlowLayout.LEFT));
	        model.addColumn("Job ID");
	        model.addColumn("Job title");
	        model.addColumn("Applicant ID");
	        model.addColumn("Applicant Name");
	        
			jtbl.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
			jtbl.getColumnModel().getColumn(0).setPreferredWidth(70);
			jtbl.getColumnModel().getColumn(1).setPreferredWidth(100);
			jtbl.getColumnModel().getColumn(2).setPreferredWidth(150);
			jtbl.getColumnModel().getColumn(3).setPreferredWidth(90);
		
	        String dburl ="jdbc:oracle:thin:@localhost:1521:xe";
			String us = "shreya";
			String pas ="vasavi123";
	        try {
	        	Connection  conn=DriverManager.getConnection(dburl,us,pas);
				System.out.println("Connected");
	            PreparedStatement pstm = conn.prepareStatement("SELECT * FROM applied_job_list_Rec");
	            ResultSet Rs = pstm.executeQuery();
	            while(Rs.next()){
	                model.addRow(new Object[]{Rs.getInt(1), Rs.getString(2),Rs.getInt(3),Rs.getString(4)});
	            }
	        } catch (Exception e) {
	            System.out.println(e.getMessage());
	        }
			
	        JScrollPane pg = new JScrollPane(jtbl);
	        pg.setBounds(200,200,10000,10000);
			cnt.setSize(1000,1000);
	        pg.createHorizontalScrollBar();
	        pg.createVerticalScrollBar();
	        cnt.add(pg);
	        this.pack();
	        this.add(cnt);
	    }
}