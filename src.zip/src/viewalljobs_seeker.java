import java.awt.*;

import javax.swing.*;

public class viewalljobs_seeker {
	
	viewalljobs_seeker(){
	
		JFrame frame = new Job_List_seeker();
		
        frame.setTitle("Jobs Available");
        frame.setSize(5000, 3000);
        frame.setLocationRelativeTo(null);
		frame.pack();
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE); 
	    
	}
}