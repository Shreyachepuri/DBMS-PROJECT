import java.awt.*;

import javax.swing.*;

public class viewall_Users {
	
	viewall_Users(){
	
		JFrame frame = new list_user();
		
        frame.setTitle("Users List");
        frame.setSize(5000,3000);
		//frame.setMinimumSize(new Dimension(500,500));
        frame.setLocationRelativeTo(null);
		frame.pack();
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE); 
		
	    
	}
	
}