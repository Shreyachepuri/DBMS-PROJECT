import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Recruiter extends JFrame{
	private JFrame frame= new JFrame();
    private JLabel l1 = new JLabel("POST A JOB");	
	private JButton b1=new JButton("Add Job");
	private JLabel l2 = new JLabel("AVAILABLE JOBS");
	private JButton b2=new JButton("Job List");
	private JLabel l3 = new JLabel("APPLIED JOBS LIST");
	private JButton b3=new JButton("Applied Job List");
	//private JButton b4=new JButton("Profile");
	public Recruiter(){       
        frame.setTitle("Recruiter Page");
        frame.setLayout(null); 
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE); 
        frame.setBounds(20,20,600,400); 		
        
		
		frame.add(b1);
		frame.add(b2);
		frame.add(l1);
		frame.add(l2);
		frame.add(l3);
		frame.add(b3);
		//frame.getContentPane().add(b4);
		l1.setBounds(30,60,200,40);
		l1.setFont(new Font("Times New Roman",Font.BOLD,17));
		l2.setBounds(30,110,200,40);
		l2.setFont(new Font("Times New Roman",Font.BOLD,17));
		b1.setBounds(270,60,170,40);
		l3.setBounds(30,160,200,40);
		l3.setFont(new Font("Times New Roman",Font.BOLD,17));
		b1.setFont(new Font("Times New Roman",Font.BOLD,17));
		b2.setBounds(270,110,170,40);
		b2.setFont(new Font("Times New Roman",Font.BOLD,17));
		b3.setBounds(270,160,170,40);
		b3.setFont(new Font("Times New Roman",Font.BOLD,17));
			
        b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				new Addjob();
			}
		});
		
      b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				new viewalljobs_recruiter();
			}
		});
        b3.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent ae) {
				new viewallapplied_jobs_rec();
			}
		 });
        // b4.addActionListener(new ActionListener() {
			// public void actionPerformed(ActionEvent ae) {
				// new Profile();
			//}
		//});*/		
			
			frame.setVisible(true); 
	    }
		
	
	
	public static void main(String args[]){
		new Recruiter();
    }
}
