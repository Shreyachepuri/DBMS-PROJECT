import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class MainPage extends JFrame{
	
	private JFrame frame= new JFrame(); 
	private JLabel lable = new JLabel();

	private JLabel l1 = new JLabel("NEW USER??");
	private JButton b1=new JButton("REGISTER");
	private JLabel l2 = new JLabel("EXISTING USER!!");
	private JButton b2=new JButton("LOGIN");
	private JButton b3=new JButton("LOGIN AS ADMIN");
	
	private JMenuBar mBar;
    private JMenu mnuHelp;
    private JMenuItem abt;
	public MainPage(){       
        frame.setTitle("Home Page");
        frame.setLayout(null); 
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
        frame.setBounds(100,150,1000,900); 
		Container c=frame.getContentPane(); 
		frame.getContentPane().add(b1);
		frame.getContentPane().add(b2);
		frame.getContentPane().add(l1);
		frame.getContentPane().add(l2);
		frame.getContentPane().add(b3);
		
		initializeMenuBar();
        frame.setJMenuBar(mBar);
		abt.addActionListener(new HelpMenuActionListener());
		JLabel label=new JLabel("CONSULTANCY SERVICES FOR JOB HUNT");
        label.setBounds(200,5,700,50);	
        label.setFont(new Font("Serif",Font.PLAIN,30));	
		lable.setIcon(new ImageIcon("C:/Users/ANUDEEP/Downloads/Dbms/job.jpg"));
	    
	    lable.setBounds(10,7,600,600);
	
        l1.setBounds(700,100,170,40);		
		b1.setBounds(700,150,170,40);
		b1.setFont(new Font("Times New Roman",Font.BOLD,17));
		l2.setBounds(700,200,170,40);
		b2.setBounds(700,250,170,40);
		b2.setFont(new Font("Times New Roman",Font.BOLD,17));
		b3.setBounds(680,320,220,40);
		b3.setFont(new Font("Times New Roman",Font.BOLD,17));
		
        b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				new HomePage1();
			}
		});
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				new Login();
			}
		});
       b3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				new AdminLogin();
			}
		});
		
             c.add(label);
			 c.add(lable);
			 
			frame.setVisible(true); 
	    }
		public void initializeMenuBar()
	    {
			mBar=new JMenuBar();
			mnuHelp=new JMenu("Help");
			abt=new JMenuItem("About");
			mnuHelp.add(abt);
			mBar.add(mnuHelp);
	    }	
		private class HelpMenuActionListener implements ActionListener {
			public void actionPerformed(ActionEvent ae) {
			if(ae.getSource()==abt)
			{
				String details;
				details = "This project is to enable interactions between employers and applicants"+"\n"+
                          "It has 3 main tables:"+"\n"+
                          "1.Admin Jobseeker and Recruiter"+"\n"+
                          "2.Admin further accessed to adding a recruiter and viewing the Recruiter List and Userlist"+"\n"+
                          "3.JobSeeker accessed with profile and jobslist and applied jobs list"+"\n"+
						  "4.Recruiter accessed with Adding Jobs and jobslist and applied jobs list";
				JOptionPane.showMessageDialog(null,details,"INFORMATION", JOptionPane.INFORMATION_MESSAGE);
			}
		  }
		}
	
	
	public static void main(String args[]){
		new MainPage();
    }
}
