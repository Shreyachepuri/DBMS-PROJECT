import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class profile
{
    JFrame frame = new JFrame("PROFILE");

    JLabel heading = new JLabel("USER PROFILE");

    //JLabel Id = new JLabel("APPLICANT_ID : ");
    JLabel Name = new JLabel("NAME :");
    JLabel email = new JLabel("EMAIL: ");
    JLabel con = new JLabel("CONTACT : ");
    JLabel gen = new JLabel("GENDER: ");
    JLabel skills = new JLabel("SKILLS : ");
    JLabel qual = new JLabel("QUALIFICATION: ");
	JLabel work = new JLabel("ANY WORK EXPERIENCE(YES/NO): ");
    JLabel go_to = new JLabel("GOTO");

    

    //List ids = new List(15);

    
    JTextField tName = new JTextField();
    JTextField temail = new JTextField();
    JTextField tcon = new JTextField();
    JTextField tgen = new JTextField();
    JTextField tskills = new JTextField();
    JTextField tqual = new JTextField();
	JTextField twork = new JTextField();
	
    
    // resultText = new JTextArea();
    
    JButton home = new JButton("Home");
    JButton submit = new JButton("SUBMIT");
    JButton back = new JButton("Back");

    Statement stmt;
    
    public void connDb() {
    	try{
            //Class.forName("oracle.jdbc.driver.OracleDriver");
        
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","shreya","vasavi123");
            //stmt = con.createStatement();
            System.out.println("connection successful");
//            con.close();
        }
        catch(SQLException e){
            System.out.println(e);
        }
    }

   /* public void loadProducts(){

        try 
        {
		  Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","shreya","vasavi123");
          ResultSet rs;
		  //PreparedStatement stmt = con.prepareStatement("SELECT APPLICANT_ID FROM jobseeker");
          rs = stmt.executeQuery();
          
          while (rs.next()) 
          {
            ids.add(rs.getString(1));
          }
        } 
        catch (SQLException e) 
        { 
          displaySQLErrors(e);
        }
    }*/
    /*private void displaySQLErrors(SQLException e) 
    {
        JOptionPane.showMessageDialog(frame,"Enter valid data types");  
        resultText.append("\nSQLException: " + e.getMessage() + "\n");
        resultText.append("SQLState:     " + e.getSQLState() + "\n");
        resultText.append("VendorError:  " + e.getErrorCode() + "\n");
    }*/

    public profile(){
    	
    	connDb();
        //loadProducts();

        //ids.setBounds(50, 100, 200, 350);
        heading.setBounds(150, 50, 100, 20);
        
        Name.setBounds(300, 150, 200, 30);
        tName.setBounds(450, 150, 150, 30);
		
        email.setBounds(300, 200, 150, 30);
        temail.setBounds(450, 200, 150, 30);
		
        con.setBounds(300, 250, 150, 30);
        tcon.setBounds(450, 250,150, 30);
		
        gen.setBounds(300, 300, 150, 30);
        tgen.setBounds(450, 300, 150, 30);
		
        skills.setBounds(300, 350, 150, 30);
        tskills.setBounds(450, 350, 150, 30);
		
        qual.setBounds(300, 400, 150, 30);
        tqual.setBounds(450, 400, 150, 30);
		
		work.setBounds(300, 450, 150, 30);
        twork.setBounds(450, 450, 150, 30);
		
       // resultText.setBounds(300, 450, 300, 150);
   
      
        
        submit.setBounds(50, 470, 100, 30);
        go_to.setBounds(50, 500, 100, 30);
        home.setBounds(50, 550, 100, 30);
        back.setBounds(50, 600, 100, 30);
        
        //Color Blue = new Color(187, 255, 153);
		//frame.getContentPane().setBackground(Blue);

        //frame.add(ids);
        frame.add(heading);
        //frame.add(Id);
        frame.add(Name);
        //frame.add(tpId);
        frame.add(tName);
		
        frame.add(em);
        frame.add(temail);
		
        frame.add(con);
        frame.add(tcon);
		
        frame.add(gen);
        frame.add(tgen);
		
        frame.add(skills);
        frame.add(tskills);
		
        frame.add(qual);
        frame.add(tqual);
		
		frame.add(work);
        frame.add(twork);
		
        frame.add(submit);
        frame.add(go_to);
        frame.add(home); 
        //frame.add(resultText);
        frame.add(back);
        
        frame.setLayout(null);  
        frame.setVisible(true);
        frame.setBounds(10, 10, 700, 700);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setResizable(false);  
		
		submit.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent ae) {
            
            try {	
			  
                    
				    Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","shreya","vasavi123");
				    PreparedStatement stmt=con.prepareStatement("insert into jobseeker values(?,?,?,?,?,?,?)");
					if(tName.getText()=="");
					{
						JOptionPane.showMessageDialog(new JFrame(),"Please Insert values!","NOTICE",JOptionPane.INFORMATION_MESSAGE);
					}
					
						//stmt.setInt(1,Integer.parseInt(tfId.getText()));	
						stmt.setString(1,tName.getText());	
						stmt.setString(2,temail.getText());	
						stmt.setInt(3,Integer.parseInt(tcon.getText()));	
						stmt.setString(4,tgen.getText());	
						stmt.setString(5,tskills.getText());	
						stmt.setString(6,tqual.getText());
						stmt.setString(7,twork.getText());
										
                    int i=stmt.executeUpdate();
					if(i>0)
					{
						JOptionPane.showMessageDialog(new JFrame(),"Successfully Inserted!","NOTICE",JOptionPane.INFORMATION_MESSAGE); 
					}
                    /*System.out.println(i + "records inserted");	
					resultText.append("Inserted" + i + "rows successfully"); */
					frame.dispose();
					new Jobseeker1();
					con.close();
                    
	                 
	             
            }
            catch(SQLException e){
                System.out.println(e);
            }
            

            
        }});


       /* ids.addItemListener(new ItemListener() {
		public void itemStateChanged(ItemEvent ae) {
            
            try     
            {
				    Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","shreya","vasavi123");
                    System.out.println("connection successful");
            	    ResultSet rs;
					PreparedStatement stmt = con.prepareStatement("SELECT * FROM jobseeker where APPLICANT_ID ='"+ids.getSelectedItem()+"'");
					rs = stmt.executeQuery();
                    rs.next();
                    tpId.setText(String.valueOf(rs.getString(1)));
                    tpName.setText(rs.getString(2));
                    tDescription.setText(rs.getString(3));
                    date.setText(rs.getString(4));
                    tcourse.setText(String.valueOf(rs.getString(5)));
                    tcode.setText(rs.getString(6));
                    tscore.setText(rs.getString(7));
					tqal.setText(rs.getString(8));
            	    
                } 
                catch (SQLException selectException) 
                {
                    displaySQLErrors(selectException);
                }
        }});

        update.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent ae) {
            try 
                {   

//                    Statement statement = con.createStatement();
                    int i = stmt.executeUpdate("UPDATE jobseeker "
                    + "SET APPLICANT_ID=" + tpId.getText() + ", "
                    + "PASSWORD='" + tpName.getText() + "', "
                    + "NAME= '" + tDescription.getText() + "', "
                    + "EMAIL='" + date.getText() + "', "
                    + "CONTACT='" + tcourse.getText() + "', "
                    + "GENDER='" + tcode.getText() + "', "
                    + "QUALIFICATION ="+ tscore.getText() + "SKILLS ="+ tqal.getText() + " WHERE applicant_id = "
                    + ids.getSelectedItem());
                    if(i>0)
					{
						JOptionPane.showMessageDialog(new JFrame(),"Successfully Updated!","NOTICE",JOptionPane.INFORMATION_MESSAGE); 
                    //resultText.append("\nUpdated " + i + " rows successfully");
					}
                    //resultText.append("\nUpdated " + i + " rows successfully");
                    ids.removeAll();
                    loadProducts();
                } 
                catch (SQLException insertException) 
                {
                    displaySQLErrors(insertException);
                }   
         
        }});*/

        home.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent ae) {
            frame.dispose();
            new HomePage1();
            // new clickListener();
         
        }});
        
        back.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
               frame.dispose();
               new Admin1();
               // new clickListener();
            
           }});
   
    }   
}