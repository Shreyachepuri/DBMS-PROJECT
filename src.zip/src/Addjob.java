import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import javax.swing.*;
//import java.util.*;

public class Addjob
{
    JFrame frame = new JFrame("Insert");
    JLabel heading = new JLabel("ADD JOB");
	JLabel l1 = new JLabel("Job ID : ");
    JLabel l2 = new JLabel("Job Title :");
    JLabel l3= new JLabel("Job Description : ");
    JLabel l4 = new JLabel("Category Id: ");
    JLabel l5 = new JLabel("Company Id : ");
    JLabel l6 = new JLabel("Type : ");
	JLabel l7 = new JLabel("Salary : ");
	JLabel l8 = new JLabel("Posting Date : ");
	JLabel l9 = new JLabel("Last Date : ");
	JLabel l10 = new JLabel("No of Vacancies : ");
	JLabel l11 = new JLabel("Status : ");
	JLabel l12 = new JLabel("Want to Modify?? ");
    JLabel go_to = new JLabel("GOTO");

    JTextField tf1 = new JTextField();
    JTextField tf2 = new JTextField();
    JTextField tf3 = new JTextField();
	JTextField tf4 = new JTextField();
    JTextField tf5 = new JTextField();
    JTextField tf6 = new JTextField();
	JTextField tf7 = new JTextField();
	JTextField tf8 = new JTextField();
	JTextField tf9 = new JTextField();
	JTextField tf10 = new JTextField();
	JTextField tf11= new JTextField();
    JTextArea resultText = new JTextArea();
    
    JButton home = new JButton("Home");
    JButton insert = new JButton("Submit");
	JButton update = new JButton("modify");
    JButton back = new JButton("Back");

    PreparedStatement stmt;
   

    public Addjob(){
    	
    	


        heading.setBounds(50, 50, 100, 20);
        l1.setBounds(50, 100, 130, 30);
        l2.setBounds(50, 150, 200, 30);
        tf1.setBounds(250, 100, 150, 30); 
       	tf2.setBounds(250, 150, 150, 30);
        l3.setBounds(50, 200, 150, 30);
        tf3.setBounds(250, 200, 150, 30);
        l4.setBounds(50, 250, 150, 30);
        tf4.setBounds(250, 250,150, 30);
		
        l5.setBounds(500, 100, 150, 30);
        tf5.setBounds(650, 100, 150, 30);
		
        l6.setBounds(500, 150, 150, 30);
        tf6.setBounds(650, 150, 150, 30);
		
		l7.setBounds(500, 200, 150, 30);
        tf7.setBounds(650, 200, 150, 30);
		
		l8.setBounds(500, 250, 150, 30);
        tf8.setBounds(650, 250, 150, 30);
		
		l9.setBounds(500, 300, 150, 30);
        tf9.setBounds(650, 300, 150, 30);
		
		l10.setBounds(500, 350, 150, 30);
        tf10.setBounds(650, 350, 150, 30);
		
		l11.setBounds(500, 400, 150, 30);
        tf11.setBounds(650, 400, 150, 30);
        
        resultText.setBounds(50, 300, 200, 150);
        
        insert.setBounds(550, 550, 100, 30);
		l12.setBounds(750, 500, 100, 30);
		update.setBounds(750, 550, 100, 30);
		
        go_to.setBounds(50, 500, 100, 30);
        home.setBounds(50, 550, 100, 30);
        back.setBounds(200, 550, 100, 30);

        frame.add(heading);
        frame.add(l1);
        frame.add(l2);
        frame.add(tf1);
        frame.add(tf2);
        frame.add(l3);
        frame.add(tf3);
        frame.add(l4);
        frame.add(tf4);
        frame.add(l5);
        frame.add(tf5);
        frame.add(l6);
        frame.add(tf6);
		
		frame.add(l7);
        frame.add(tf7);
		
		frame.add(l8);
        frame.add(tf8);
		
		frame.add(l9);
        frame.add(tf9);
		
		frame.add(l10);
        frame.add(tf10);
		
		frame.add(l11);
        frame.add(tf11);
        
		frame.add(l12);
        frame.add(insert);
		frame.add(update);
        frame.add(go_to);
        frame.add(home); 
        frame.add(resultText);
        frame.add(back);
        
        frame.setLayout(null);  
        frame.setVisible(true);
        frame.setBounds(10, 10, 1000, 1000);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setResizable(true);  

        insert.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent ae) {
            
            try {	
			  
                    
				    Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","shreya","vasavi123");
				    PreparedStatement stmt=con.prepareStatement("insert into job_information values(?,?,?,?,?,?,?,?,?,?,?)");
					if(tf1.getText()=="");
					{
						JOptionPane.showMessageDialog(new JFrame(),"Please Insert values!","NOTICE",JOptionPane.INFORMATION_MESSAGE);
					
					}
                    stmt.setInt(1,Integer.parseInt(tf1.getText()));	
                    stmt.setString(2,tf2.getText());	
                    stmt.setString(3,tf3.getText());	
                    stmt.setInt(4,Integer.parseInt(tf4.getText()));	
                    stmt.setInt(5,Integer.parseInt(tf5.getText()));	
                    stmt.setString(6,tf6.getText());	
                    stmt.setInt(7,Integer.parseInt(tf7.getText()));
					Date date = Date.valueOf(tf8.getText());
					stmt.setDate(8,date);
					Date date1 = Date.valueOf(tf9.getText());
					stmt.setDate(9,date1);
					stmt.setInt(10,Integer.parseInt(tf10.getText()));
					stmt.setString(11,tf11.getText());
					int i=stmt.executeUpdate();
					
					if(i>0)
					{
						JOptionPane.showMessageDialog(new JFrame(),"Please Insert values!","NOTICE",JOptionPane.INFORMATION_MESSAGE);
					}
                    System.out.println(i + "records inserted");	
					resultText.append("Inserted" +" " +i+" " + "rows successfully"); 
					con.close();
					
                   
					
                    
	                 
	             
            }
            catch(SQLException e){
                System.out.println(e);
            }
            

            
        }});
		
		update.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent ae) {
            frame.dispose();
            new update_job();
            
         
        }});

        home.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent ae) {
            frame.dispose();
            new HomePage1();
            
         
        }});
        
        back.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
               frame.dispose();
               new Recruiter();
              
            
           }});
   
    }   
}



